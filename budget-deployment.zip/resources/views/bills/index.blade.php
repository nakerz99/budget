@extends('layouts.app')

@section('title', 'Bills & Subscriptions')

@section('content')
<div>
    <!-- Header -->
    <div class="mb-6">
        <div class="flex justify-between items-center mb-4">
            <h1 class="text-2xl font-bold text-gray-800">Bills & Subscriptions</h1>
            <button onclick="showAddBillModal()" class="btn btn-primary">
                <i class="fas fa-plus"></i>
                Add Bill
            </button>
        </div>
    </div>

    <!-- Summary Cards -->
    <div class="stats-grid mb-6">
        <div class="stat-card expense">
            <div class="stat-icon">📅</div>
            <div class="stat-value">{{ $upcomingBills->count() }}</div>
            <div class="stat-label">Upcoming Bills</div>
        </div>
        
        <div class="stat-card balance">
            <div class="stat-icon">💰</div>
            <div class="stat-value">{{ currency_symbol() }}{{ number_format($totalUpcoming, 0) }}</div>
            <div class="stat-label">Total Due</div>
        </div>
        
        <div class="stat-card income">
            <div class="stat-icon">✅</div>
            <div class="stat-value">{{ $paidBills->count() }}</div>
            <div class="stat-label">Paid This Month</div>
        </div>
        
        <div class="stat-card">
            <div class="stat-icon">🔄</div>
            <div class="stat-value">{{ $recurringBills->count() }}</div>
            <div class="stat-label">Recurring Bills</div>
        </div>
    </div>

    <!-- Upcoming Bills -->
    <div class="card mb-6">
        <div class="card-header">
            <i class="fas fa-calendar-alt"></i> Upcoming Bills
        </div>
        <div class="card-body">
            @if($upcomingBills->count() > 0)
                <div class="space-y-3">
                    @foreach($upcomingBills as $bill)
                    <div class="bill-item {{ $bill->due_date->isToday() ? 'urgent' : '' }}">
                        <div class="flex items-center justify-between p-4 rounded-lg {{ $bill->due_date->isToday() ? 'bg-red-50 border border-red-200' : 'bg-gray-50' }}">
                            <div class="flex items-center gap-4">
                                <div class="w-12 h-12 rounded-full flex items-center justify-center {{ $bill->due_date->isToday() ? 'bg-red-100 text-red-600' : 'bg-blue-100 text-blue-600' }}">
                                    <i class="fas fa-file-invoice"></i>
                                </div>
                                <div>
                                    <div class="font-semibold text-gray-800">{{ $bill->name }}</div>
                                    <div class="text-sm text-gray-600">
                                        @if($bill->is_recurring)
                                            <i class="fas fa-sync-alt"></i> Recurring
                                        @else
                                            <i class="fas fa-calendar"></i> One-time
                                        @endif
                                        • {{ $bill->category->name }}
                                    </div>
                                    <div class="text-xs text-gray-500">
                                        Due {{ $bill->due_date->format('M d, Y') }}
                                        @if($bill->due_date->isToday())
                                            <span class="text-red-600 font-semibold">• Due Today!</span>
                                        @elseif($bill->due_date->isTomorrow())
                                            <span class="text-orange-600 font-semibold">• Due Tomorrow</span>
                                        @else
                                            • {{ $bill->due_date->diffForHumans() }}
                                        @endif
                                    </div>
                                </div>
                            </div>
                            <div class="text-right">
                                <div class="font-bold text-lg text-gray-800">
                                    {{ currency_symbol() }}{{ number_format($bill->amount, 0) }}
                                </div>
                                <div class="flex gap-2 mt-2">
                                    <form method="POST" action="{{ route('bills.markPaid', $bill) }}" class="inline">
                                        @csrf
                                        <button type="submit" class="btn btn-sm btn-success">
                                            <i class="fas fa-check"></i>
                                            Mark Paid
                                        </button>
                                    </form>
                                    <button onclick="editBill({{ $bill->id }})" class="btn btn-sm btn-secondary">
                                        <i class="fas fa-edit"></i>
                                    </button>
                                    <form method="POST" action="{{ route('bills.destroy', $bill) }}" 
                                          onsubmit="return confirm('Are you sure you want to delete this bill?')" 
                                          class="inline">
                                        @csrf
                                        @method('DELETE')
                                        <button type="submit" class="btn btn-sm btn-danger">
                                            <i class="fas fa-trash"></i>
                                        </button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                    @endforeach
                </div>
            @else
                <div class="text-center py-12">
                    <div class="text-6xl mb-4">📅</div>
                    <h3 class="text-xl font-semibold text-gray-800 mb-2">No upcoming bills</h3>
                    <p class="text-gray-600 mb-6">Add your first bill or subscription to start tracking!</p>
                    <button onclick="showAddBillModal()" class="btn btn-primary btn-lg">
                        <i class="fas fa-plus"></i>
                        Add Bill
                    </button>
                </div>
            @endif
        </div>
    </div>

    <!-- Paid Bills This Month -->
    @if($paidBills->count() > 0)
    <div class="card mb-6">
        <div class="card-header">
            <i class="fas fa-check-circle"></i> Paid This Month
        </div>
        <div class="card-body">
            <div class="space-y-3">
                @foreach($paidBills as $bill)
                <div class="flex items-center justify-between p-3 bg-green-50 rounded-lg">
                    <div class="flex items-center gap-3">
                        <div class="w-8 h-8 rounded-full bg-green-100 flex items-center justify-center">
                            <i class="fas fa-check text-green-600"></i>
                        </div>
                        <div>
                            <div class="font-medium text-gray-800">{{ $bill->name }}</div>
                            <div class="text-sm text-gray-600">
                                Paid on {{ $bill->paid_at->format('M d, Y') }}
                            </div>
                        </div>
                    </div>
                    <div class="text-right">
                        <div class="font-semibold text-gray-800">
                            {{ currency_symbol() }}{{ number_format($bill->amount, 0) }}
                        </div>
                        <form method="POST" action="{{ route('bills.markUnpaid', $bill) }}" class="inline">
                            @csrf
                            <button type="submit" class="btn btn-sm btn-secondary">
                                <i class="fas fa-undo"></i>
                                Mark Unpaid
                            </button>
                        </form>
                    </div>
                </div>
                @endforeach
            </div>
        </div>
    </div>
    @endif

    <!-- All Bills -->
    <div class="card">
        <div class="card-header">
            <i class="fas fa-list"></i> All Bills
        </div>
        <div class="card-body">
            @if($allBills->count() > 0)
                <div class="table-container">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Bill Name</th>
                                <th>Amount</th>
                                <th>Due Date</th>
                                <th>Status</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach($allBills as $bill)
                            <tr>
                                <td>
                                    <div class="flex items-center gap-3">
                                        <div class="w-8 h-8 rounded-full flex items-center justify-center" 
                                             style="background: {{ $bill->category->color }}20; color: {{ $bill->category->color }};">
                                            <i class="fas fa-file-invoice"></i>
                                        </div>
                                        <div>
                                            <div class="font-medium text-gray-800">{{ $bill->name }}</div>
                                            <div class="text-sm text-gray-600">{{ $bill->category->name }}</div>
                                        </div>
                                    </div>
                                </td>
                                <td class="font-semibold text-gray-800">
                                    {{ currency_symbol() }}{{ number_format($bill->amount, 0) }}
                                </td>
                                <td>
                                    <div class="text-sm text-gray-800">{{ $bill->due_date->format('M d, Y') }}</div>
                                    <div class="text-xs text-gray-500">{{ $bill->due_date->diffForHumans() }}</div>
                                </td>
                                <td>
                                    @if($bill->is_paid)
                                        <span class="badge badge-success">Paid</span>
                                    @elseif($bill->due_date->isPast())
                                        <span class="badge badge-danger">Overdue</span>
                                    @elseif($bill->due_date->isToday())
                                        <span class="badge badge-warning">Due Today</span>
                                    @else
                                        <span class="badge badge-secondary">Pending</span>
                                    @endif
                                </td>
                                <td>
                                    <div class="flex gap-2">
                                        @if(!$bill->is_paid)
                                            <form method="POST" action="{{ route('bills.markPaid', $bill) }}" class="inline">
                                                @csrf
                                                <button type="submit" class="btn btn-sm btn-success">
                                                    <i class="fas fa-check"></i>
                                                </button>
                                            </form>
                                        @else
                                            <form method="POST" action="{{ route('bills.markUnpaid', $bill) }}" class="inline">
                                                @csrf
                                                <button type="submit" class="btn btn-sm btn-secondary">
                                                    <i class="fas fa-undo"></i>
                                                </button>
                                            </form>
                                        @endif
                                        <button onclick="editBill({{ $bill->id }})" class="btn btn-sm btn-secondary">
                                            <i class="fas fa-edit"></i>
                                        </button>
                                        <form method="POST" action="{{ route('bills.destroy', $bill) }}" 
                                              onsubmit="return confirm('Are you sure you want to delete this bill?')" 
                                              class="inline">
                                            @csrf
                                            @method('DELETE')
                                            <button type="submit" class="btn btn-sm btn-danger">
                                                <i class="fas fa-trash"></i>
                                            </button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            @else
                <div class="text-center py-12">
                    <div class="text-6xl mb-4">📄</div>
                    <h3 class="text-xl font-semibold text-gray-800 mb-2">No bills found</h3>
                    <p class="text-gray-600 mb-6">Add your first bill to start tracking your expenses!</p>
                    <button onclick="showAddBillModal()" class="btn btn-primary btn-lg">
                        <i class="fas fa-plus"></i>
                        Add Bill
                    </button>
                </div>
            @endif
        </div>
    </div>
</div>

<!-- Add Bill Modal -->
<div id="addBillModal" class="hidden fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
    <div class="bg-white rounded-lg max-w-md w-full max-h-[90vh] overflow-y-auto">
        <div class="p-6">
            <div class="flex justify-between items-center mb-4">
                <h3 class="text-lg font-semibold text-gray-800">Add Bill</h3>
                <button onclick="hideAddBillModal()" class="text-gray-400 hover:text-gray-600">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            
            <form method="POST" action="{{ route('bills.store') }}">
                @csrf
                <div class="form-group">
                    <label class="form-label">Bill Name</label>
                    <input type="text" name="name" class="form-control" 
                           placeholder="e.g., Electricity Bill" required>
                </div>
                
                <div class="form-group">
                    <label class="form-label">Amount</label>
                    <input type="number" name="amount" class="form-control" 
                           placeholder="0.00" step="0.01" min="0" required>
                </div>
                
                <div class="form-group">
                    <label class="form-label">Due Date</label>
                    <input type="date" name="due_date" class="form-control" 
                           value="{{ now()->addDays(7)->format('Y-m-d') }}" required>
                </div>
                
                <div class="form-group">
                    <label class="form-label">Category</label>
                    <select name="category_id" class="form-select" required>
                        <option value="">Select Category</option>
                        @foreach($categories as $category)
                            <option value="{{ $category->id }}">{{ $category->name }}</option>
                        @endforeach
                    </select>
                </div>
                
                <div class="form-group">
                    <label class="form-label">
                        <input type="checkbox" name="is_recurring" value="1" class="mr-2">
                        Recurring Bill
                    </label>
                </div>
                
                <div class="flex gap-3 mt-6">
                    <button type="button" onclick="hideAddBillModal()" class="btn btn-secondary flex-1">
                        Cancel
                    </button>
                    <button type="submit" class="btn btn-primary flex-1">
                        Add Bill
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<style>
    .space-y-3 > * + * { margin-top: 0.75rem; }
    .w-12 { width: 3rem; }
    .h-12 { height: 3rem; }
    .w-8 { width: 2rem; }
    .h-8 { height: 2rem; }
    .gap-3 { gap: 0.75rem; }
    .gap-4 { gap: 1rem; }
    .gap-2 { gap: 0.5rem; }
    .items-center { align-items: center; }
    .justify-between { justify-content: space-between; }
    .justify-center { justify-content: center; }
    .text-right { text-align: right; }
    .text-center { text-align: center; }
    .text-left { text-align: left; }
    .rounded-lg { border-radius: 0.5rem; }
    .rounded-full { border-radius: 9999px; }
    .p-3 { padding: 0.75rem; }
    .p-4 { padding: 1rem; }
    .p-6 { padding: 1.5rem; }
    .mt-2 { margin-top: 0.5rem; }
    .mt-6 { margin-top: 1.5rem; }
    .mb-2 { margin-bottom: 0.5rem; }
    .mb-4 { margin-bottom: 1rem; }
    .mb-6 { margin-bottom: 1.5rem; }
    .py-12 { padding-top: 3rem; padding-bottom: 3rem; }
    .text-6xl { font-size: 3.75rem; }
    .text-xl { font-size: 1.25rem; }
    .text-lg { font-size: 1.125rem; }
    .text-sm { font-size: 0.875rem; }
    .text-xs { font-size: 0.75rem; }
    .text-2xl { font-size: 1.5rem; }
    .font-semibold { font-weight: 600; }
    .font-bold { font-weight: 700; }
    .font-medium { font-weight: 500; }
    .text-gray-500 { color: #6b7280; }
    .text-gray-600 { color: #4b5563; }
    .text-gray-800 { color: #1f2937; }
    .text-green-600 { color: #059669; }
    .text-red-600 { color: #dc2626; }
    .text-orange-600 { color: #ea580c; }
    .bg-gray-50 { background-color: #f9fafb; }
    .bg-green-50 { background-color: #f0fdf4; }
    .bg-red-50 { background-color: #fef2f2; }
    .bg-blue-100 { background-color: #dbeafe; }
    .bg-red-100 { background-color: #fee2e2; }
    .bg-green-100 { background-color: #dcfce7; }
    .text-blue-600 { color: #2563eb; }
    .text-red-600 { color: #dc2626; }
    .text-green-600 { color: #059669; }
    .border { border-width: 1px; }
    .border-red-200 { border-color: #fecaca; }
    .flex { display: flex; }
    .grid { display: grid; }
    .hidden { display: none; }
    .block { display: block; }
    .inline { display: inline; }
    .w-full { width: 100%; }
    .flex-1 { flex: 1 1 0%; }
    .max-w-md { max-width: 28rem; }
    .max-h-\[90vh\] { max-height: 90vh; }
    .overflow-y-auto { overflow-y: auto; }
    .fixed { position: fixed; }
    .inset-0 { top: 0; right: 0; bottom: 0; left: 0; }
    .z-50 { z-index: 50; }
    .bg-black { background-color: #000000; }
    .bg-opacity-50 { background-color: rgba(0, 0, 0, 0.5); }
    .bg-white { background-color: #ffffff; }
    .text-gray-400 { color: #9ca3af; }
    .hover\:text-gray-600:hover { color: #4b5563; }
    .mr-2 { margin-right: 0.5rem; }
    
    .bill-item.urgent {
        animation: pulse 2s infinite;
    }
    
    @keyframes pulse {
        0%, 100% { opacity: 1; }
        50% { opacity: 0.8; }
    }
</style>

<script>
    function showAddBillModal() {
        document.getElementById('addBillModal').classList.remove('hidden');
    }
    
    function hideAddBillModal() {
        document.getElementById('addBillModal').classList.add('hidden');
    }
    
    function editBill(billId) {
        // TODO: Implement edit functionality
        alert('Edit functionality coming soon!');
    }
    
    // Close modal when clicking outside
    document.addEventListener('click', function(event) {
        const modal = document.getElementById('addBillModal');
        if (event.target === modal) {
            hideAddBillModal();
        }
    });
</script>
@endsection