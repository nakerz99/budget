@extends('layouts.app')

@section('title', 'Budget')

@section('content')
<div>
    <!-- Header -->
    <div class="mb-6">
        <div class="flex justify-between items-center mb-4">
            <h1 class="text-2xl font-bold text-gray-800">Monthly Budget</h1>
            <div class="flex gap-2">
                <button onclick="copyFromLastMonth()" class="btn btn-secondary">
                    <i class="fas fa-copy"></i>
                    Copy Last Month
                </button>
                <button onclick="showAddBudgetModal()" class="btn btn-primary">
                    <i class="fas fa-plus"></i>
                    Add Budget
                </button>
            </div>
        </div>
        
        <!-- Month Selector -->
        <div class="card">
            <div class="card-body">
                <form method="GET" class="flex gap-4 items-end">
                    <div class="form-group flex-1">
                        <label class="form-label">Select Month</label>
                        <select name="month" class="form-select" onchange="this.form.submit()">
                            @for($i = 1; $i <= 12; $i++)
                                <option value="{{ $i }}" {{ $currentMonth == $i ? 'selected' : '' }}>
                                    {{ date('F', mktime(0, 0, 0, $i, 1)) }} {{ $currentYear }}
                                </option>
                            @endfor
                        </select>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Budget Summary -->
    <div class="stats-grid mb-6">
        <div class="stat-card income">
            <div class="stat-icon">📊</div>
            <div class="stat-value">{{ currency_symbol() }}{{ number_format($totalBudget, 0) }}</div>
            <div class="stat-label">Total Budget</div>
        </div>
        
        <div class="stat-card expense">
            <div class="stat-icon">💸</div>
            <div class="stat-value">{{ currency_symbol() }}{{ number_format($totalSpent, 0) }}</div>
            <div class="stat-label">Total Spent</div>
        </div>
        
        <div class="stat-card balance">
            <div class="stat-icon">💰</div>
            <div class="stat-value">{{ currency_symbol() }}{{ number_format($remainingBudget, 0) }}</div>
            <div class="stat-label">Remaining</div>
        </div>
        
        <div class="stat-card">
            <div class="stat-icon">📈</div>
            <div class="stat-value">{{ $totalBudget > 0 ? number_format(($totalSpent / $totalBudget) * 100, 1) : 0 }}%</div>
            <div class="stat-label">Used</div>
        </div>
    </div>

    <!-- Budget Categories -->
    <div class="card mb-6">
        <div class="card-header">
            <i class="fas fa-chart-pie"></i> Budget by Category
        </div>
        <div class="card-body">
            @if($budgets->count() > 0)
                <div class="space-y-4">
                    @foreach($budgets as $budget)
                    <div class="budget-item">
                        <div class="flex items-center justify-between mb-2">
                            <div class="flex items-center gap-3">
                                <div class="w-10 h-10 rounded-full flex items-center justify-center" 
                                     style="background: {{ $budget->category->color }}20; color: {{ $budget->category->color }};">
                                    <i class="fas fa-tag"></i>
                                </div>
                                <div>
                                    <div class="font-semibold text-gray-800">{{ $budget->category->name }}</div>
                                    <div class="text-sm text-gray-600">
                                        {{ currency_symbol() }}{{ number_format($budget->amount, 0) }} budget
                                    </div>
                                </div>
                            </div>
                            <div class="text-right">
                                <div class="font-bold text-lg {{ $budget->spent > $budget->amount ? 'text-red-600' : 'text-gray-800' }}">
                                    {{ currency_symbol() }}{{ number_format($budget->spent, 0) }}
                                </div>
                                <div class="text-sm text-gray-600">spent</div>
                            </div>
                        </div>
                        
                        <!-- Progress Bar -->
                        <div class="w-full bg-gray-200 rounded-full h-3 mb-2">
                            @php
                                $percentage = $budget->amount > 0 ? min(100, ($budget->spent / $budget->amount) * 100) : 0;
                                $barColor = $percentage > 100 ? '#ef4444' : ($percentage > 80 ? '#f59e0b' : '#3b82f6');
                            @endphp
                            <div class="h-3 rounded-full transition-all duration-300" 
                                 style="width: {{ $percentage }}%; background: {{ $barColor }};"></div>
                        </div>
                        
                        <div class="flex justify-between items-center text-sm">
                            <span class="text-gray-600">
                                {{ number_format($percentage, 1) }}% used
                            </span>
                            <span class="text-gray-600">
                                {{ currency_symbol() }}{{ number_format($budget->amount - $budget->spent, 0) }} remaining
                            </span>
                        </div>
                    </div>
                    @endforeach
                </div>
            @else
                <div class="text-center py-12">
                    <div class="text-6xl mb-4">📊</div>
                    <h3 class="text-xl font-semibold text-gray-800 mb-2">No budget set for this month</h3>
                    <p class="text-gray-600 mb-6">Create your first budget to start tracking your spending!</p>
                    <button onclick="showAddBudgetModal()" class="btn btn-primary btn-lg">
                        <i class="fas fa-plus"></i>
                        Create Budget
                    </button>
                </div>
            @endif
        </div>
    </div>

    <!-- Budget vs Actual Chart -->
    @if($budgets->count() > 0)
    <div class="card">
        <div class="card-header">
            <i class="fas fa-chart-bar"></i> Budget vs Actual
        </div>
        <div class="card-body">
            <div class="space-y-3">
                @foreach($budgets as $budget)
                <div class="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                    <div class="flex items-center gap-3">
                        <div class="w-8 h-8 rounded-full flex items-center justify-center" 
                             style="background: {{ $budget->category->color }}20; color: {{ $budget->category->color }};">
                            <i class="fas fa-tag text-sm"></i>
                        </div>
                        <span class="font-medium text-gray-800">{{ $budget->category->name }}</span>
                    </div>
                    <div class="flex items-center gap-4">
                        <div class="text-right">
                            <div class="text-sm text-gray-600">Budget</div>
                            <div class="font-semibold">{{ currency_symbol() }}{{ number_format($budget->amount, 0) }}</div>
                        </div>
                        <div class="text-right">
                            <div class="text-sm text-gray-600">Actual</div>
                            <div class="font-semibold {{ $budget->spent > $budget->amount ? 'text-red-600' : 'text-gray-800' }}">
                                {{ currency_symbol() }}{{ number_format($budget->spent, 0) }}
                            </div>
                        </div>
                        <div class="text-right">
                            <div class="text-sm text-gray-600">Diff</div>
                            <div class="font-semibold {{ ($budget->amount - $budget->spent) < 0 ? 'text-red-600' : 'text-green-600' }}">
                                {{ ($budget->amount - $budget->spent) < 0 ? '-' : '' }}{{ currency_symbol() }}{{ number_format(abs($budget->amount - $budget->spent), 0) }}
                            </div>
                        </div>
                    </div>
                </div>
                @endforeach
            </div>
        </div>
    </div>
    @endif
</div>

<!-- Add Budget Modal -->
<div id="addBudgetModal" class="hidden fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
    <div class="bg-white rounded-lg max-w-md w-full max-h-[90vh] overflow-y-auto">
        <div class="p-6">
            <div class="flex justify-between items-center mb-4">
                <h3 class="text-lg font-semibold text-gray-800">Add Budget</h3>
                <button onclick="hideAddBudgetModal()" class="text-gray-400 hover:text-gray-600">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            
            <form method="POST" action="{{ route('budget.store') }}">
                @csrf
                <div class="form-group">
                    <label class="form-label">Category</label>
                    <select name="category_id" class="form-select" required>
                        <option value="">Select Category</option>
                        @foreach($categories as $category)
                            <option value="{{ $category->id }}">{{ $category->name }}</option>
                        @endforeach
                    </select>
                </div>
                
                <div class="form-group">
                    <label class="form-label">Amount</label>
                    <input type="number" name="amount" class="form-control" 
                           placeholder="0.00" step="0.01" min="0" required>
                </div>
                
                <div class="flex gap-3 mt-6">
                    <button type="button" onclick="hideAddBudgetModal()" class="btn btn-secondary flex-1">
                        Cancel
                    </button>
                    <button type="submit" class="btn btn-primary flex-1">
                        Add Budget
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<style>
    .space-y-4 > * + * { margin-top: 1rem; }
    .space-y-3 > * + * { margin-top: 0.75rem; }
    .w-10 { width: 2.5rem; }
    .h-10 { height: 2.5rem; }
    .w-8 { width: 2rem; }
    .h-8 { height: 2rem; }
    .h-3 { height: 0.75rem; }
    .gap-3 { gap: 0.75rem; }
    .gap-4 { gap: 1rem; }
    .gap-2 { gap: 0.5rem; }
    .items-center { align-items: center; }
    .items-end { align-items: flex-end; }
    .justify-between { justify-content: space-between; }
    .justify-center { justify-content: center; }
    .text-right { text-align: right; }
    .text-center { text-align: center; }
    .text-left { text-align: left; }
    .rounded-lg { border-radius: 0.5rem; }
    .rounded-full { border-radius: 9999px; }
    .p-3 { padding: 0.75rem; }
    .p-4 { padding: 1rem; }
    .p-6 { padding: 1.5rem; }
    .mt-2 { margin-top: 0.5rem; }
    .mt-6 { margin-top: 1.5rem; }
    .mb-2 { margin-bottom: 0.5rem; }
    .mb-4 { margin-bottom: 1rem; }
    .mb-6 { margin-bottom: 1.5rem; }
    .py-12 { padding-top: 3rem; padding-bottom: 3rem; }
    .text-6xl { font-size: 3.75rem; }
    .text-xl { font-size: 1.25rem; }
    .text-lg { font-size: 1.125rem; }
    .text-sm { font-size: 0.875rem; }
    .text-2xl { font-size: 1.5rem; }
    .font-semibold { font-weight: 600; }
    .font-bold { font-weight: 700; }
    .font-medium { font-weight: 500; }
    .text-gray-500 { color: #6b7280; }
    .text-gray-600 { color: #4b5563; }
    .text-gray-800 { color: #1f2937; }
    .text-green-600 { color: #059669; }
    .text-red-600 { color: #dc2626; }
    .bg-gray-50 { background-color: #f9fafb; }
    .bg-gray-200 { background-color: #e5e7eb; }
    .flex { display: flex; }
    .grid { display: grid; }
    .hidden { display: none; }
    .block { display: block; }
    .inline { display: inline; }
    .w-full { width: 100%; }
    .flex-1 { flex: 1 1 0%; }
    .max-w-md { max-width: 28rem; }
    .max-h-\[90vh\] { max-height: 90vh; }
    .overflow-y-auto { overflow-y: auto; }
    .fixed { position: fixed; }
    .inset-0 { top: 0; right: 0; bottom: 0; left: 0; }
    .z-50 { z-index: 50; }
    .bg-black { background-color: #000000; }
    .bg-opacity-50 { background-color: rgba(0, 0, 0, 0.5); }
    .bg-white { background-color: #ffffff; }
    .text-gray-400 { color: #9ca3af; }
    .hover\:text-gray-600:hover { color: #4b5563; }
    .transition-all { transition-property: all; transition-timing-function: cubic-bezier(0.4, 0, 0.2, 1); transition-duration: 150ms; }
    .duration-300 { transition-duration: 300ms; }
    
    .budget-item {
        padding: 1rem;
        background: white;
        border-radius: 0.75rem;
        border: 1px solid #e5e7eb;
        transition: all 0.2s;
    }
    
    .budget-item:hover {
        box-shadow: var(--shadow-md);
        transform: translateY(-1px);
    }
</style>

<script>
    function showAddBudgetModal() {
        document.getElementById('addBudgetModal').classList.remove('hidden');
    }
    
    function hideAddBudgetModal() {
        document.getElementById('addBudgetModal').classList.add('hidden');
    }
    
    function copyFromLastMonth() {
        if (confirm('Copy budget from last month?')) {
            window.location.href = '{{ route("budget.copy", ["month" => $currentMonth - 1, "year" => $currentYear]) }}';
        }
    }
    
    // Close modal when clicking outside
    document.addEventListener('click', function(event) {
        const modal = document.getElementById('addBudgetModal');
        if (event.target === modal) {
            hideAddBudgetModal();
        }
    });
</script>
@endsection