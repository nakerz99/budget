@extends('layouts.app')

@section('title', 'Dashboard')

@section('content')
<div>
    <!-- Welcome Section -->
    <div class="mb-6">
        <h1 class="text-2xl font-bold text-gray-800 mb-2">
            Welcome back, {{ $user->full_name }}! 👋
        </h1>
        <p class="text-gray-600">Here's your financial overview for {{ now()->format('F Y') }}</p>
    </div>

    <!-- Stats Grid -->
    <div class="stats-grid">
        <div class="stat-card expense">
            <div class="stat-icon">💸</div>
            <div class="stat-value">{{ currency_symbol() }}{{ number_format(abs($monthlySpending), 0) }}</div>
            <div class="stat-label">Monthly Spending</div>
        </div>

        <div class="stat-card balance">
            <div class="stat-icon">💰</div>
            <div class="stat-value">{{ currency_symbol() }}{{ number_format($accountBalance, 0) }}</div>
            <div class="stat-label">Account Balance</div>
        </div>

        <div class="stat-card income">
            <div class="stat-icon">📈</div>
            <div class="stat-value">{{ currency_symbol() }}{{ number_format($monthlyBudget, 0) }}</div>
            <div class="stat-label">Monthly Budget</div>
        </div>

        <div class="stat-card savings">
            <div class="stat-icon">🎯</div>
            <div class="stat-value">{{ $savingsGoalsCount }}</div>
            <div class="stat-label">Savings Goals</div>
        </div>
    </div>

    <!-- Quick Actions -->
    <div class="card mb-6">
        <div class="card-header">
            <i class="fas fa-bolt"></i> Quick Actions
        </div>
        <div class="card-body">
            <div class="btn-group">
                <a href="{{ route('transactions.create') }}" class="btn btn-primary">
                    <i class="fas fa-plus"></i>
                    Add Transaction
                </a>
                <a href="{{ route('budget.index') }}" class="btn btn-secondary">
                    <i class="fas fa-chart-pie"></i>
                    Set Budget
                </a>
            </div>
            <div class="btn-group mt-3">
                <a href="{{ route('savings.index') }}" class="btn btn-secondary">
                    <i class="fas fa-piggy-bank"></i>
                    Savings Goal
                </a>
                <a href="{{ route('bills.index') }}" class="btn btn-secondary">
                    <i class="fas fa-file-invoice"></i>
                    Manage Bills
                </a>
            </div>
        </div>
    </div>

    <!-- Recent Transactions -->
    <div class="card mb-6">
        <div class="card-header">
            <i class="fas fa-history"></i> Recent Transactions
        </div>
        <div class="card-body">
            @if($recentTransactions->count() > 0)
                <div class="table-container">
                    <table class="table">
                        <tbody>
                            @foreach($recentTransactions as $transaction)
                            <tr>
                                <td>
                                    <div class="flex items-center gap-3">
                                        <div class="w-10 h-10 rounded-full flex items-center justify-center" style="background: {{ $transaction->category->color }}20; color: {{ $transaction->category->color }};">
                                            <i class="fas fa-{{ $transaction->type === 'income' ? 'arrow-up' : 'arrow-down' }}"></i>
                                        </div>
                                        <div>
                                            <div class="font-medium text-gray-800">{{ Str::limit($transaction->description ?: 'No description', 25) }}</div>
                                            <div class="text-sm text-gray-500">{{ $transaction->category->name }}</div>
                                        </div>
                                    </div>
                                </td>
                                <td class="text-right">
                                    <div class="font-semibold {{ $transaction->type === 'income' ? 'text-green-600' : 'text-red-600' }}">
                                        {{ $transaction->type === 'income' ? '+' : '-' }}{{ currency_symbol() }}{{ number_format($transaction->amount, 0) }}
                                    </div>
                                    <div class="text-sm text-gray-500">{{ $transaction->transaction_date->format('M d') }}</div>
                                </td>
                            </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
                <div class="text-center mt-4">
                    <a href="{{ route('transactions.index') }}" class="btn btn-sm btn-primary">
                        View All Transactions
                    </a>
                </div>
            @else
                <div class="text-center py-8">
                    <div class="text-4xl mb-4">📝</div>
                    <h3 class="text-lg font-semibold text-gray-800 mb-2">No transactions yet</h3>
                    <p class="text-gray-600 mb-4">Start by adding your first transaction!</p>
                    <a href="{{ route('transactions.create') }}" class="btn btn-primary">
                        <i class="fas fa-plus"></i>
                        Add Transaction
                    </a>
                </div>
            @endif
        </div>
    </div>

    <!-- Upcoming Bills -->
    @if($upcomingBills->count() > 0)
    <div class="card mb-6">
        <div class="card-header">
            <i class="fas fa-calendar-alt"></i> Upcoming Bills
        </div>
        <div class="card-body">
            <div class="table-container">
                <table class="table">
                    <tbody>
                        @foreach($upcomingBills as $bill)
                        <tr>
                            <td>
                                <div class="flex items-center gap-3">
                                    <div class="w-10 h-10 rounded-full bg-orange-100 flex items-center justify-center">
                                        <i class="fas fa-file-invoice text-orange-600"></i>
                                    </div>
                                    <div>
                                        <div class="font-medium text-gray-800">{{ $bill->name }}</div>
                                        <div class="text-sm text-gray-500">Due {{ $bill->due_date->format('M d, Y') }}</div>
                                    </div>
                                </div>
                            </td>
                            <td class="text-right">
                                <div class="font-semibold text-gray-800">{{ currency_symbol() }}{{ number_format($bill->amount, 0) }}</div>
                                <div class="text-sm text-gray-500">
                                    @if($bill->due_date->isToday())
                                        <span class="text-red-600">Due Today</span>
                                    @elseif($bill->due_date->isTomorrow())
                                        <span class="text-orange-600">Due Tomorrow</span>
                                    @else
                                        {{ $bill->due_date->diffForHumans() }}
                                    @endif
                                </div>
                            </td>
                        </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
            <div class="text-center mt-4">
                <a href="{{ route('bills.index') }}" class="btn btn-sm btn-warning">
                    View All Bills
                </a>
            </div>
        </div>
    </div>
    @endif

    <!-- Savings Goals -->
    @if($savingsGoals->count() > 0)
    <div class="card mb-6">
        <div class="card-header">
            <i class="fas fa-piggy-bank"></i> Savings Goals
        </div>
        <div class="card-body">
            @foreach($savingsGoals as $goal)
            <div class="mb-4 last:mb-0">
                <div class="flex justify-between items-center mb-2">
                    <div class="font-medium text-gray-800">{{ $goal->name }}</div>
                    <div class="text-sm text-gray-600">{{ currency_symbol() }}{{ number_format($goal->current_amount, 0) }} / {{ currency_symbol() }}{{ number_format($goal->target_amount, 0) }}</div>
                </div>
                <div class="w-full bg-gray-200 rounded-full h-2">
                    <div class="bg-blue-600 h-2 rounded-full" style="width: {{ min(100, ($goal->current_amount / $goal->target_amount) * 100) }}%"></div>
                </div>
                <div class="text-xs text-gray-500 mt-1">
                    {{ number_format(($goal->current_amount / $goal->target_amount) * 100, 1) }}% complete
                </div>
            </div>
            @endforeach
            <div class="text-center mt-4">
                <a href="{{ route('savings.index') }}" class="btn btn-sm btn-primary">
                    Manage Goals
                </a>
            </div>
        </div>
    </div>
    @endif

    <!-- Getting Started (for new users) -->
    @if($recentTransactions->count() == 0)
    <div class="card">
        <div class="card-header">
            <i class="fas fa-rocket"></i> Getting Started
        </div>
        <div class="card-body">
            <div class="grid grid-cols-1 gap-4">
                <div class="p-4 bg-blue-50 rounded-lg">
                    <div class="flex items-start gap-3">
                        <div class="w-8 h-8 bg-blue-600 rounded-full flex items-center justify-center text-white font-bold">1</div>
                        <div>
                            <h3 class="font-semibold text-gray-800 mb-1">Add Your First Account</h3>
                            <p class="text-sm text-gray-600 mb-3">Create accounts for your checking, savings, and credit cards.</p>
                            <a href="{{ route('settings.index') }}" class="btn btn-sm btn-primary">Add Account</a>
                        </div>
                    </div>
                </div>
                
                <div class="p-4 bg-green-50 rounded-lg">
                    <div class="flex items-start gap-3">
                        <div class="w-8 h-8 bg-green-600 rounded-full flex items-center justify-center text-white font-bold">2</div>
                        <div>
                            <h3 class="font-semibold text-gray-800 mb-1">Set Up Categories</h3>
                            <p class="text-sm text-gray-600 mb-3">Create categories for your expenses and income.</p>
                            <a href="{{ route('settings.index') }}" class="btn btn-sm btn-success">Manage Categories</a>
                        </div>
                    </div>
                </div>
                
                <div class="p-4 bg-purple-50 rounded-lg">
                    <div class="flex items-start gap-3">
                        <div class="w-8 h-8 bg-purple-600 rounded-full flex items-center justify-center text-white font-bold">3</div>
                        <div>
                            <h3 class="font-semibold text-gray-800 mb-1">Create Your First Budget</h3>
                            <p class="text-sm text-gray-600 mb-3">Set monthly spending limits for different categories.</p>
                            <a href="{{ route('budget.index') }}" class="btn btn-sm btn-warning">Set Budget</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    @endif
</div>

<style>
    .w-10 { width: 2.5rem; }
    .h-10 { height: 2.5rem; }
    .w-8 { width: 2rem; }
    .h-8 { height: 2rem; }
    .h-2 { height: 0.5rem; }
    .gap-3 { gap: 0.75rem; }
    .gap-4 { gap: 1rem; }
    .items-center { align-items: center; }
    .items-start { align-items: flex-start; }
    .justify-center { justify-content: center; }
    .justify-between { justify-content: space-between; }
    .rounded-full { border-radius: 9999px; }
    .rounded-lg { border-radius: 0.5rem; }
    .text-green-600 { color: #059669; }
    .text-red-600 { color: #dc2626; }
    .text-orange-600 { color: #ea580c; }
    .text-gray-500 { color: #6b7280; }
    .text-gray-600 { color: #4b5563; }
    .text-gray-800 { color: #1f2937; }
    .bg-orange-100 { background-color: #fed7aa; }
    .bg-blue-50 { background-color: #eff6ff; }
    .bg-green-50 { background-color: #f0fdf4; }
    .bg-purple-50 { background-color: #faf5ff; }
    .bg-blue-600 { background-color: #2563eb; }
    .bg-green-600 { background-color: #059669; }
    .bg-purple-600 { background-color: #9333ea; }
    .text-orange-600 { color: #ea580c; }
    .text-white { color: white; }
    .font-bold { font-weight: 700; }
    .font-semibold { font-weight: 600; }
    .font-medium { font-weight: 500; }
    .last\:mb-0:last-child { margin-bottom: 0; }
    .grid-cols-1 { grid-template-columns: repeat(1, minmax(0, 1fr)); }
    .p-4 { padding: 1rem; }
    .mb-1 { margin-bottom: 0.25rem; }
    .mb-2 { margin-bottom: 0.5rem; }
    .mb-3 { margin-bottom: 0.75rem; }
    .mb-4 { margin-bottom: 1rem; }
    .mb-6 { margin-bottom: 1.5rem; }
    .mt-1 { margin-top: 0.25rem; }
    .mt-3 { margin-top: 0.75rem; }
    .mt-4 { margin-top: 1rem; }
    .py-8 { padding-top: 2rem; padding-bottom: 2rem; }
    .text-4xl { font-size: 2.25rem; }
    .text-lg { font-size: 1.125rem; }
    .text-sm { font-size: 0.875rem; }
    .text-xs { font-size: 0.75rem; }
    .text-2xl { font-size: 1.5rem; }
    .text-center { text-align: center; }
    .text-right { text-align: right; }
    .flex { display: flex; }
    .grid { display: grid; }
    .hidden { display: none; }
    .block { display: block; }
    .w-full { width: 100%; }
    .bg-gray-200 { background-color: #e5e7eb; }
    .bg-blue-600 { background-color: #2563eb; }
    .rounded-full { border-radius: 9999px; }
    .h-2 { height: 0.5rem; }
    .min-100 { min-width: 100%; }
</style>
@endsection