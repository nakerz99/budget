@extends('layouts.app')

@section('title', 'Savings Goals')

@section('content')
<div>
    <!-- Header -->
    <div class="mb-6">
        <div class="flex justify-between items-center mb-4">
            <h1 class="text-2xl font-bold text-gray-800">Savings Goals</h1>
            <button onclick="showAddGoalModal()" class="btn btn-primary">
                <i class="fas fa-plus"></i>
                Add Goal
            </button>
        </div>
    </div>

    <!-- Summary Cards -->
    <div class="stats-grid mb-6">
        <div class="stat-card savings">
            <div class="stat-icon">🎯</div>
            <div class="stat-value">{{ $savingsGoals->count() }}</div>
            <div class="stat-label">Active Goals</div>
        </div>
        
        <div class="stat-card balance">
            <div class="stat-icon">💰</div>
            <div class="stat-value">{{ currency_symbol() }}{{ number_format($totalSaved, 0) }}</div>
            <div class="stat-label">Total Saved</div>
        </div>
        
        <div class="stat-card income">
            <div class="stat-icon">📈</div>
            <div class="stat-value">{{ currency_symbol() }}{{ number_format($totalTarget, 0) }}</div>
            <div class="stat-label">Total Target</div>
        </div>
        
        <div class="stat-card">
            <div class="stat-icon">✅</div>
            <div class="stat-value">{{ $completedGoals->count() }}</div>
            <div class="stat-label">Completed</div>
        </div>
    </div>

    <!-- Active Savings Goals -->
    <div class="card mb-6">
        <div class="card-header">
            <i class="fas fa-piggy-bank"></i> Active Goals
        </div>
        <div class="card-body">
            @if($savingsGoals->count() > 0)
                <div class="space-y-4">
                    @foreach($savingsGoals as $goal)
                    <div class="savings-goal-item">
                        <div class="p-4 bg-gradient-to-r from-blue-50 to-indigo-50 rounded-lg border border-blue-200">
                            <div class="flex items-center justify-between mb-4">
                                <div class="flex items-center gap-3">
                                    <div class="w-12 h-12 rounded-full bg-blue-100 flex items-center justify-center">
                                        <i class="fas fa-{{ $goal->icon ?: 'piggy-bank' }} text-blue-600"></i>
                                    </div>
                                    <div>
                                        <div class="font-semibold text-gray-800 text-lg">{{ $goal->name }}</div>
                                        <div class="text-sm text-gray-600">
                                            Target: {{ currency_symbol() }}{{ number_format($goal->target_amount, 0) }}
                                            @if($goal->target_date)
                                                • Due {{ $goal->target_date->format('M d, Y') }}
                                            @endif
                                        </div>
                                    </div>
                                </div>
                                <div class="text-right">
                                    <div class="font-bold text-xl text-gray-800">
                                        {{ currency_symbol() }}{{ number_format($goal->current_amount, 0) }}
                                    </div>
                                    <div class="text-sm text-gray-600">
                                        {{ number_format(($goal->current_amount / $goal->target_amount) * 100, 1) }}% complete
                                    </div>
                                </div>
                            </div>
                            
                            <!-- Progress Bar -->
                            <div class="w-full bg-gray-200 rounded-full h-3 mb-4">
                                @php
                                    $percentage = min(100, ($goal->current_amount / $goal->target_amount) * 100);
                                    $barColor = $percentage >= 100 ? '#10b981' : ($percentage >= 75 ? '#3b82f6' : '#f59e0b');
                                @endphp
                                <div class="h-3 rounded-full transition-all duration-500" 
                                     style="width: {{ $percentage }}%; background: {{ $barColor }};"></div>
                            </div>
                            
                            <div class="flex justify-between items-center">
                                <div class="text-sm text-gray-600">
                                    {{ currency_symbol() }}{{ number_format($goal->target_amount - $goal->current_amount, 0) }} remaining
                                </div>
                                <div class="flex gap-2">
                                    <button onclick="addContribution({{ $goal->id }})" class="btn btn-sm btn-success">
                                        <i class="fas fa-plus"></i>
                                        Add Money
                                    </button>
                                    <button onclick="editGoal({{ $goal->id }})" class="btn btn-sm btn-secondary">
                                        <i class="fas fa-edit"></i>
                                    </button>
                                    <form method="POST" action="{{ route('savings.destroyGoal', $goal) }}" 
                                          onsubmit="return confirm('Are you sure you want to delete this goal?')" 
                                          class="inline">
                                        @csrf
                                        @method('DELETE')
                                        <button type="submit" class="btn btn-sm btn-danger">
                                            <i class="fas fa-trash"></i>
                                        </button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                    @endforeach
                </div>
            @else
                <div class="text-center py-12">
                    <div class="text-6xl mb-4">🎯</div>
                    <h3 class="text-xl font-semibold text-gray-800 mb-2">No savings goals yet</h3>
                    <p class="text-gray-600 mb-6">Create your first savings goal to start building your financial future!</p>
                    <button onclick="showAddGoalModal()" class="btn btn-primary btn-lg">
                        <i class="fas fa-plus"></i>
                        Create Goal
                    </button>
                </div>
            @endif
        </div>
    </div>

    <!-- Completed Goals -->
    @if($completedGoals->count() > 0)
    <div class="card mb-6">
        <div class="card-header">
            <i class="fas fa-trophy"></i> Completed Goals
        </div>
        <div class="card-body">
            <div class="space-y-3">
                @foreach($completedGoals as $goal)
                <div class="flex items-center justify-between p-3 bg-green-50 rounded-lg border border-green-200">
                    <div class="flex items-center gap-3">
                        <div class="w-8 h-8 rounded-full bg-green-100 flex items-center justify-center">
                            <i class="fas fa-trophy text-green-600"></i>
                        </div>
                        <div>
                            <div class="font-medium text-gray-800">{{ $goal->name }}</div>
                            <div class="text-sm text-gray-600">
                                Completed {{ $goal->updated_at->format('M d, Y') }}
                            </div>
                        </div>
                    </div>
                    <div class="text-right">
                        <div class="font-semibold text-green-600">
                            {{ currency_symbol() }}{{ number_format($goal->target_amount, 0) }}
                        </div>
                        <div class="text-sm text-gray-600">Achieved!</div>
                    </div>
                </div>
                @endforeach
            </div>
        </div>
    </div>
    @endif

    <!-- Savings Accounts -->
    <div class="card">
        <div class="card-header">
            <i class="fas fa-university"></i> Savings Accounts
        </div>
        <div class="card-body">
            @if($savingsAccounts->count() > 0)
                <div class="space-y-3">
                    @foreach($savingsAccounts as $account)
                    <div class="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                        <div class="flex items-center gap-3">
                            <div class="w-10 h-10 rounded-full bg-blue-100 flex items-center justify-center">
                                <i class="fas fa-university text-blue-600"></i>
                            </div>
                            <div>
                                <div class="font-semibold text-gray-800">{{ $account->name }}</div>
                                <div class="text-sm text-gray-600">{{ $account->account_type }}</div>
                            </div>
                        </div>
                        <div class="text-right">
                            <div class="font-bold text-lg text-gray-800">
                                {{ currency_symbol() }}{{ number_format($account->balance, 0) }}
                            </div>
                            <div class="text-sm text-gray-600">Balance</div>
                        </div>
                    </div>
                    @endforeach
                </div>
            @else
                <div class="text-center py-8">
                    <div class="text-4xl mb-4">🏦</div>
                    <h3 class="text-lg font-semibold text-gray-800 mb-2">No savings accounts</h3>
                    <p class="text-gray-600 mb-4">Add a savings account to track your money!</p>
                    <button onclick="showAddAccountModal()" class="btn btn-primary">
                        <i class="fas fa-plus"></i>
                        Add Account
                    </button>
                </div>
            @endif
        </div>
    </div>
</div>

<!-- Add Goal Modal -->
<div id="addGoalModal" class="hidden fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
    <div class="bg-white rounded-lg max-w-md w-full max-h-[90vh] overflow-y-auto">
        <div class="p-6">
            <div class="flex justify-between items-center mb-4">
                <h3 class="text-lg font-semibold text-gray-800">Create Savings Goal</h3>
                <button onclick="hideAddGoalModal()" class="text-gray-400 hover:text-gray-600">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            
            <form method="POST" action="{{ route('savings.storeGoal') }}">
                @csrf
                <div class="form-group">
                    <label class="form-label">Goal Name</label>
                    <input type="text" name="name" class="form-control" 
                           placeholder="e.g., Emergency Fund" required>
                </div>
                
                <div class="form-group">
                    <label class="form-label">Target Amount</label>
                    <input type="number" name="target_amount" class="form-control" 
                           placeholder="0.00" step="0.01" min="0" required>
                </div>
                
                <div class="form-group">
                    <label class="form-label">Current Amount</label>
                    <input type="number" name="current_amount" class="form-control" 
                           placeholder="0.00" step="0.01" min="0" value="0">
                </div>
                
                <div class="form-group">
                    <label class="form-label">Target Date (Optional)</label>
                    <input type="date" name="target_date" class="form-control">
                </div>
                
                <div class="form-group">
                    <label class="form-label">Description (Optional)</label>
                    <textarea name="description" class="form-control" rows="3" 
                              placeholder="Describe your savings goal..."></textarea>
                </div>
                
                <div class="flex gap-3 mt-6">
                    <button type="button" onclick="hideAddGoalModal()" class="btn btn-secondary flex-1">
                        Cancel
                    </button>
                    <button type="submit" class="btn btn-primary flex-1">
                        Create Goal
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Add Contribution Modal -->
<div id="addContributionModal" class="hidden fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
    <div class="bg-white rounded-lg max-w-md w-full">
        <div class="p-6">
            <div class="flex justify-between items-center mb-4">
                <h3 class="text-lg font-semibold text-gray-800">Add Contribution</h3>
                <button onclick="hideAddContributionModal()" class="text-gray-400 hover:text-gray-600">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            
            <form method="POST" action="{{ route('savings.addContribution') }}">
                @csrf
                <input type="hidden" name="goal_id" id="contributionGoalId">
                
                <div class="form-group">
                    <label class="form-label">Amount</label>
                    <input type="number" name="amount" class="form-control" 
                           placeholder="0.00" step="0.01" min="0.01" required>
                </div>
                
                <div class="form-group">
                    <label class="form-label">Description (Optional)</label>
                    <input type="text" name="description" class="form-control" 
                           placeholder="e.g., Monthly contribution">
                </div>
                
                <div class="flex gap-3 mt-6">
                    <button type="button" onclick="hideAddContributionModal()" class="btn btn-secondary flex-1">
                        Cancel
                    </button>
                    <button type="submit" class="btn btn-success flex-1">
                        Add Contribution
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Add Account Modal -->
<div id="addAccountModal" class="hidden fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
    <div class="bg-white rounded-lg max-w-md w-full">
        <div class="p-6">
            <div class="flex justify-between items-center mb-4">
                <h3 class="text-lg font-semibold text-gray-800">Add Savings Account</h3>
                <button onclick="hideAddAccountModal()" class="text-gray-400 hover:text-gray-600">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            
            <form method="POST" action="{{ route('savings.storeAccount') }}">
                @csrf
                <div class="form-group">
                    <label class="form-label">Account Name</label>
                    <input type="text" name="name" class="form-control" 
                           placeholder="e.g., High-Yield Savings" required>
                </div>
                
                <div class="form-group">
                    <label class="form-label">Account Type</label>
                    <select name="account_type" class="form-select" required>
                        <option value="savings">Savings Account</option>
                        <option value="money_market">Money Market</option>
                        <option value="cd">Certificate of Deposit</option>
                        <option value="investment">Investment Account</option>
                    </select>
                </div>
                
                <div class="form-group">
                    <label class="form-label">Initial Balance</label>
                    <input type="number" name="balance" class="form-control" 
                           placeholder="0.00" step="0.01" min="0" value="0">
                </div>
                
                <div class="flex gap-3 mt-6">
                    <button type="button" onclick="hideAddAccountModal()" class="btn btn-secondary flex-1">
                        Cancel
                    </button>
                    <button type="submit" class="btn btn-primary flex-1">
                        Add Account
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<style>
    .space-y-4 > * + * { margin-top: 1rem; }
    .space-y-3 > * + * { margin-top: 0.75rem; }
    .w-12 { width: 3rem; }
    .h-12 { height: 3rem; }
    .w-10 { width: 2.5rem; }
    .h-10 { height: 2.5rem; }
    .w-8 { width: 2rem; }
    .h-8 { height: 2rem; }
    .h-3 { height: 0.75rem; }
    .gap-3 { gap: 0.75rem; }
    .gap-4 { gap: 1rem; }
    .gap-2 { gap: 0.5rem; }
    .items-center { align-items: center; }
    .justify-between { justify-content: space-between; }
    .justify-center { justify-content: center; }
    .text-right { text-align: right; }
    .text-center { text-align: center; }
    .text-left { text-align: left; }
    .rounded-lg { border-radius: 0.5rem; }
    .rounded-full { border-radius: 9999px; }
    .p-3 { padding: 0.75rem; }
    .p-4 { padding: 1rem; }
    .p-6 { padding: 1.5rem; }
    .py-8 { padding-top: 2rem; padding-bottom: 2rem; }
    .py-12 { padding-top: 3rem; padding-bottom: 3rem; }
    .mt-2 { margin-top: 0.5rem; }
    .mt-4 { margin-top: 1rem; }
    .mt-6 { margin-top: 1.5rem; }
    .mb-2 { margin-bottom: 0.5rem; }
    .mb-4 { margin-bottom: 1rem; }
    .mb-6 { margin-bottom: 1.5rem; }
    .text-6xl { font-size: 3.75rem; }
    .text-4xl { font-size: 2.25rem; }
    .text-xl { font-size: 1.25rem; }
    .text-lg { font-size: 1.125rem; }
    .text-sm { font-size: 0.875rem; }
    .text-xs { font-size: 0.75rem; }
    .text-2xl { font-size: 1.5rem; }
    .font-semibold { font-weight: 600; }
    .font-bold { font-weight: 700; }
    .font-medium { font-weight: 500; }
    .text-gray-500 { color: #6b7280; }
    .text-gray-600 { color: #4b5563; }
    .text-gray-800 { color: #1f2937; }
    .text-green-600 { color: #059669; }
    .text-blue-600 { color: #2563eb; }
    .bg-gray-50 { background-color: #f9fafb; }
    .bg-green-50 { background-color: #f0fdf4; }
    .bg-blue-50 { background-color: #eff6ff; }
    .bg-blue-100 { background-color: #dbeafe; }
    .bg-green-100 { background-color: #dcfce7; }
    .bg-gradient-to-r { background-image: linear-gradient(to right, var(--tw-gradient-stops)); }
    .from-blue-50 { --tw-gradient-from: #eff6ff; --tw-gradient-stops: var(--tw-gradient-from), var(--tw-gradient-to, rgba(239, 246, 255, 0)); }
    .to-indigo-50 { --tw-gradient-to: #eef2ff; }
    .border { border-width: 1px; }
    .border-blue-200 { border-color: #bfdbfe; }
    .border-green-200 { border-color: #bbf7d0; }
    .flex { display: flex; }
    .grid { display: grid; }
    .hidden { display: none; }
    .block { display: block; }
    .inline { display: inline; }
    .w-full { width: 100%; }
    .flex-1 { flex: 1 1 0%; }
    .max-w-md { max-width: 28rem; }
    .max-h-\[90vh\] { max-height: 90vh; }
    .overflow-y-auto { overflow-y: auto; }
    .fixed { position: fixed; }
    .inset-0 { top: 0; right: 0; bottom: 0; left: 0; }
    .z-50 { z-index: 50; }
    .bg-black { background-color: #000000; }
    .bg-opacity-50 { background-color: rgba(0, 0, 0, 0.5); }
    .bg-white { background-color: #ffffff; }
    .text-gray-400 { color: #9ca3af; }
    .hover\:text-gray-600:hover { color: #4b5563; }
    .transition-all { transition-property: all; transition-timing-function: cubic-bezier(0.4, 0, 0.2, 1); transition-duration: 150ms; }
    .duration-500 { transition-duration: 500ms; }
    
    .savings-goal-item {
        transition: all 0.2s;
    }
    
    .savings-goal-item:hover {
        transform: translateY(-2px);
        box-shadow: var(--shadow-lg);
    }
</style>

<script>
    function showAddGoalModal() {
        document.getElementById('addGoalModal').classList.remove('hidden');
    }
    
    function hideAddGoalModal() {
        document.getElementById('addGoalModal').classList.add('hidden');
    }
    
    function showAddAccountModal() {
        document.getElementById('addAccountModal').classList.remove('hidden');
    }
    
    function hideAddAccountModal() {
        document.getElementById('addAccountModal').classList.add('hidden');
    }
    
    function addContribution(goalId) {
        document.getElementById('contributionGoalId').value = goalId;
        document.getElementById('addContributionModal').classList.remove('hidden');
    }
    
    function hideAddContributionModal() {
        document.getElementById('addContributionModal').classList.add('hidden');
    }
    
    function editGoal(goalId) {
        // TODO: Implement edit functionality
        alert('Edit functionality coming soon!');
    }
    
    // Close modals when clicking outside
    document.addEventListener('click', function(event) {
        const modals = ['addGoalModal', 'addContributionModal', 'addAccountModal'];
        modals.forEach(modalId => {
            const modal = document.getElementById(modalId);
            if (event.target === modal) {
                modal.classList.add('hidden');
            }
        });
    });
</script>
@endsection