@extends('layouts.app')

@section('title', 'Transactions')

@section('content')
<div>
    <!-- Header -->
    <div class="mb-6">
        <div class="flex justify-between items-center mb-4">
            <h1 class="text-2xl font-bold text-gray-800">Transactions</h1>
            <a href="{{ route('transactions.create') }}" class="btn btn-primary">
                <i class="fas fa-plus"></i>
                Add Transaction
            </a>
        </div>
        
        <!-- Filters -->
        <div class="card">
            <div class="card-body">
                <form method="GET" class="grid grid-cols-1 md:grid-cols-4 gap-4">
                    <div class="form-group">
                        <label class="form-label">Search</label>
                        <input type="text" name="search" value="{{ request('search') }}" 
                               class="form-control" placeholder="Search transactions...">
                    </div>
                    
                    <div class="form-group">
                        <label class="form-label">Type</label>
                        <select name="type" class="form-select">
                            <option value="">All Types</option>
                            <option value="income" {{ request('type') == 'income' ? 'selected' : '' }}>Income</option>
                            <option value="expense" {{ request('type') == 'expense' ? 'selected' : '' }}>Expense</option>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label class="form-label">Category</label>
                        <select name="category_id" class="form-select">
                            <option value="">All Categories</option>
                            @foreach($categories as $category)
                                <option value="{{ $category->id }}" {{ request('category_id') == $category->id ? 'selected' : '' }}>
                                    {{ $category->name }}
                                </option>
                            @endforeach
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label class="form-label">Date Range</label>
                        <select name="date_range" class="form-select">
                            <option value="">All Time</option>
                            <option value="today" {{ request('date_range') == 'today' ? 'selected' : '' }}>Today</option>
                            <option value="week" {{ request('date_range') == 'week' ? 'selected' : '' }}>This Week</option>
                            <option value="month" {{ request('date_range') == 'month' ? 'selected' : '' }}>This Month</option>
                            <option value="year" {{ request('date_range') == 'year' ? 'selected' : '' }}>This Year</option>
                        </select>
                    </div>
                    
                    <div class="col-span-full flex gap-2">
                        <button type="submit" class="btn btn-primary flex-1">
                            <i class="fas fa-search"></i>
                            Filter
                        </button>
                        <a href="{{ route('transactions.index') }}" class="btn btn-secondary">
                            <i class="fas fa-times"></i>
                            Clear
                        </a>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Summary Cards -->
    <div class="stats-grid mb-6">
        <div class="stat-card income">
            <div class="stat-icon">📈</div>
            <div class="stat-value">{{ currency_symbol() }}{{ number_format($totalIncome, 0) }}</div>
            <div class="stat-label">Total Income</div>
        </div>
        
        <div class="stat-card expense">
            <div class="stat-icon">📉</div>
            <div class="stat-value">{{ currency_symbol() }}{{ number_format($totalExpenses, 0) }}</div>
            <div class="stat-label">Total Expenses</div>
        </div>
        
        <div class="stat-card balance">
            <div class="stat-icon">💰</div>
            <div class="stat-value">{{ currency_symbol() }}{{ number_format($netAmount, 0) }}</div>
            <div class="stat-label">Net Amount</div>
        </div>
        
        <div class="stat-card">
            <div class="stat-icon">📊</div>
            <div class="stat-value">{{ $transactions->count() }}</div>
            <div class="stat-label">Transactions</div>
        </div>
    </div>

    <!-- Transactions List -->
    <div class="card">
        <div class="card-header">
            <i class="fas fa-list"></i> Transaction History
        </div>
        <div class="card-body">
            @if($transactions->count() > 0)
                <div class="space-y-4">
                    @foreach($transactions as $transaction)
                    <div class="transaction-item">
                        <div class="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                            <div class="flex items-center gap-4">
                                <div class="w-12 h-12 rounded-full flex items-center justify-center" 
                                     style="background: {{ $transaction->category->color }}20; color: {{ $transaction->category->color }};">
                                    <i class="fas fa-{{ $transaction->type === 'income' ? 'arrow-up' : 'arrow-down' }}"></i>
                                </div>
                                <div>
                                    <div class="font-semibold text-gray-800">
                                        {{ $transaction->description ?: 'No description' }}
                                    </div>
                                    <div class="text-sm text-gray-600">
                                        {{ $transaction->category->name }} • {{ $transaction->account->name }}
                                    </div>
                                    <div class="text-xs text-gray-500">
                                        {{ $transaction->transaction_date->format('M d, Y') }}
                                    </div>
                                </div>
                            </div>
                            <div class="text-right">
                                <div class="font-bold text-lg {{ $transaction->type === 'income' ? 'text-green-600' : 'text-red-600' }}">
                                    {{ $transaction->type === 'income' ? '+' : '-' }}{{ currency_symbol() }}{{ number_format($transaction->amount, 0) }}
                                </div>
                                <div class="flex gap-2 mt-2">
                                    <a href="{{ route('transactions.edit', $transaction) }}" class="btn btn-sm btn-secondary">
                                        <i class="fas fa-edit"></i>
                                    </a>
                                    <form method="POST" action="{{ route('transactions.destroy', $transaction) }}" 
                                          onsubmit="return confirm('Are you sure you want to delete this transaction?')" 
                                          class="inline">
                                        @csrf
                                        @method('DELETE')
                                        <button type="submit" class="btn btn-sm btn-danger">
                                            <i class="fas fa-trash"></i>
                                        </button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                    @endforeach
                </div>
                
                <!-- Pagination -->
                @if($transactions->hasPages())
                <div class="mt-6">
                    {{ $transactions->links() }}
                </div>
                @endif
            @else
                <div class="text-center py-12">
                    <div class="text-6xl mb-4">📝</div>
                    <h3 class="text-xl font-semibold text-gray-800 mb-2">No transactions found</h3>
                    <p class="text-gray-600 mb-6">
                        @if(request()->hasAny(['search', 'type', 'category_id', 'date_range']))
                            Try adjusting your filters or search terms.
                        @else
                            Start by adding your first transaction!
                        @endif
                    </p>
                    <a href="{{ route('transactions.create') }}" class="btn btn-primary btn-lg">
                        <i class="fas fa-plus"></i>
                        Add Transaction
                    </a>
                </div>
            @endif
        </div>
    </div>
</div>

<style>
    .space-y-4 > * + * { margin-top: 1rem; }
    .w-12 { width: 3rem; }
    .h-12 { height: 3rem; }
    .gap-4 { gap: 1rem; }
    .gap-2 { gap: 0.5rem; }
    .items-center { align-items: center; }
    .justify-between { justify-content: space-between; }
    .justify-center { justify-content: center; }
    .text-right { text-align: right; }
    .text-center { text-align: center; }
    .text-left { text-align: left; }
    .rounded-lg { border-radius: 0.5rem; }
    .rounded-full { border-radius: 9999px; }
    .p-4 { padding: 1rem; }
    .mt-2 { margin-top: 0.5rem; }
    .mt-6 { margin-top: 1.5rem; }
    .mb-2 { margin-bottom: 0.5rem; }
    .mb-4 { margin-bottom: 1rem; }
    .mb-6 { margin-bottom: 1.5rem; }
    .py-12 { padding-top: 3rem; padding-bottom: 3rem; }
    .text-6xl { font-size: 3.75rem; }
    .text-xl { font-size: 1.25rem; }
    .text-lg { font-size: 1.125rem; }
    .text-sm { font-size: 0.875rem; }
    .text-xs { font-size: 0.75rem; }
    .text-2xl { font-size: 1.5rem; }
    .font-semibold { font-weight: 600; }
    .font-bold { font-weight: 700; }
    .text-gray-500 { color: #6b7280; }
    .text-gray-600 { color: #4b5563; }
    .text-gray-800 { color: #1f2937; }
    .text-green-600 { color: #059669; }
    .text-red-600 { color: #dc2626; }
    .bg-gray-50 { background-color: #f9fafb; }
    .flex { display: flex; }
    .grid { display: grid; }
    .hidden { display: none; }
    .block { display: block; }
    .inline { display: inline; }
    .w-full { width: 100%; }
    .flex-1 { flex: 1 1 0%; }
    .col-span-full { grid-column: 1 / -1; }
    
    @media (min-width: 768px) {
        .md\:grid-cols-4 { grid-template-columns: repeat(4, minmax(0, 1fr)); }
    }
    
    .transaction-item {
        transition: all 0.2s;
    }
    
    .transaction-item:hover {
        transform: translateY(-1px);
        box-shadow: var(--shadow-md);
    }
</style>
@endsection